### Hexlet tests and linter status:
[![Actions Status](https://github.com/Bestgeo7/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Bestgeo7/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/27a7faedfba7c589c886/maintainability)](https://codeclimate.com/github/Bestgeo7/python-project-49/maintainability)

[![asciicast](https://asciinema.org/a/DvBgQ8dc255WtMy0ht2fDutRF.svg)](https://asciinema.org/a/DvBgQ8dc255WtMy0ht2fDutRF)

