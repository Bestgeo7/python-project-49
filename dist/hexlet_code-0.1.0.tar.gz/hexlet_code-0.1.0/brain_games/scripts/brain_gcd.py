#!/usr/bin/env python3
import prompt
import random
from brain_games.games.gcd import gcd

def main():
    print("Welcome to the Brain Games!")
    gcd()


if __name__ == "__main__":
    main()
